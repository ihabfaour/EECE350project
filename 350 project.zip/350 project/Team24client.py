# -*- coding: utf-8 -*-
"""
Created on Thu Apr 27 01:26:21 2023

@author: User
"""

import socket
import threading 
from tkinter import *
import random
import pygame 

#NOTICE: inorder to run this code PLEASE download the latest version of pygame (python.exe -m pip install --upgrade pip) by typing 'pip install pygame' on your terminal or CMD 
#this client is an edited copy of the original client code we made. But including a user interface and a background music for better experience
#step 1: Run the server's code first 
#step 2: Run the client's code
#step 3: When the player displays the number and tries to submit it, press the 'SPACE' button on your keyboad to move on to the other player and between rounds 
#step 4: If you want to change the color of the backhgroud on the client's window, press the 'ENTER' button on your keyboad and choose your favorite color

#Create a socket for the players 
client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Define the server address to connect to it 
host = socket.gethostname()
host_address = socket.gethostbyname(host)
#bind socket and port number 
server_address = (host_address, 8080)

#This is an extra feature to add music to the code while playing the game

#initialize pygram mixer to load the music file 
pygame.mixer.init()
#the audio is in a folder called data inside the 321Project folder. 
#load the audio file. You can download any MP3 sound you want and print its directory here inorder to change the background music 
pygame.mixer.music.load(r"data\The Game Show Theme Music (1).mp3") #https://youtu.be/UaRrDZWhtWA (Video link inverted to MP3)

#define a function to play the audio
def start_audio():
    pygame.mixer.music.play(-1)#the -1 is to keep the music playing

def stop_audio():
    pygame.mixer.music.stop()

# Define a function to connect to the server when the Start button is pressed
def connect_to_server():
    # Connect to the server 
    client_socket.connect(server_address)

    # Print the welcome message from the client and start playing the music 
    wlcm_message = client_socket.recv(1024)
    print(wlcm_message.decode())
    start_audio()

    for round in range(1, 4): # Looping over 3 rounds
        print(f"\nThis is round: {round}")

        try:
            random_number = client_socket.recv(1024).decode() #recieve the random number from the sever 
            #If the received message contains the word "timeout", it replaces the asterisk character with an empty string, 
            #sends an acknowledgement message to the server, creates a label to display the received number in the GUI, 
            #closes the client socket and returns from the function.
            if "timeout" in random_number:
                random_number = random_number.replace('*', '')
                client_socket.send("ack::timeout".encode())
                input_label = Label(root, text=random_number)
                input_label.pack()
                client_socket.close()
                return
                
        except ConnectionResetError: # an error that indicates that server closed
            print("Game server was closed")
            break
        
        # Create a label, an entry widget, and a submit button to get the user's input
        input_label = Label(root, text=f"Enter the number ASAP {random_number}: ")
        input_label.pack()
        input_entry = Entry(root, textvariable=input_entry_var)
        input_entry.pack()
        bad_input_label = Label(root, text="Bad input", fg="red")
        

        # Change the background color of the widget randomly
        r = lambda: random.randint(0, 255)
        #to congigure characters displayed by the player
        input_entry.config(bg='#%02X%02X%02X' % (r(),r(),r()))

        # Create a list of colors
        colors = ["red", "green", "blue", "yellow", "orange", "purple"]
        
        # Define a function to change the background color randomly by pressing the "Enter" button on your keyboard 
        def change_background_color():
            # Generate random RGB values for the background color
            r = random.randint(0, 255)
            g = random.randint(0, 255)
            b = random.randint(0, 255)
            color = "#" + format(r, '02x') + format(g, '02x') + format(b, '02x')
        
            # Set the background color of the window
            root.config(bg=color)
        
        # Bind a key event to the function that changes the background color
        root.bind("<Return>", lambda event: change_background_color())


        # Wait for the user to input a value and send it to the server
        player_input = ""
        while True:
            root.wait_variable(input_entry_var)#wait the player to enter the number 
            player_input = input_entry.get()#set the player_input to the value of the entry widget 
            player_input = ""#we initialize player_input first to an empty string or white space
            while not player_input:#if the player_input is no longer empty we set its value to the entry of the widget 
                root.wait_variable(input_entry_var)
                player_input = input_entry.get()
            if player_input == "" or player_input.isspace():#extra feature as well: if the player entered space instead of the number he will be given a second chance to try again
                print("Bad input")#display that the player entered a wrong input 
                bad_input_label.config(text="Bad input, delete space and try again")
                bad_input_label.pack()
                
            else:
                bad_input_label.pack_forget() # hide the label if input is valid
                break
        # Update the label widget with player input
        input_label.config(text=player_input)
        #send the player's input to the server 
        client_socket.send(player_input.encode())

        try:
            recievedMessage = "" #create an empty string to store the incoming messages
            while True:
                data = client_socket.recv(1024).decode()
                recievedMessage += data #concatinate date recieved until we found the arterisk 
                if '*' in data: # * is a type of protocol used to allow the server to identify when the round finishes
                    break# once the artesik is found the code breaks out of the loop 
            recievedMessage = recievedMessage.replace('*', '')#removes the asterisk character from the receivedMessage using the replace() method and prints the resulting message to the console.
            print(recievedMessage)
            #check if the player was timed out and inform the second player 
            if "timeout" in recievedMessage: #if the recieved message contains the work "timeout" it sends an acknowledgement message to the server
                client_socket.send("ack::timeout".encode())
                input_label = Label(root, text=recievedMessage)# Set the server message on the label
                input_label.pack()
                client_socket.close()#close the client socket and return from the function
                return
            
            server_message_label.config(text=recievedMessage) # Set the server message on the label
            client_socket.send(("next? ").encode()) # this statement allows server to take the approval of the player if he/she want to continue playing
        except ConnectionResetError: # if no approval given the server closes 
            print("Game server was closed")
            break
        input_entry.delete(0, END) # clear the value of the input entry widget
    
    try:
        # Get the final results of the game
        fin_res = client_socket.recv(1024).decode()
        print("Your final result is: ", fin_res)

        # Create a label for each player to display their final result
        player1_result = Label(root, text=f"{fin_res}")
        player1_result.pack()
    except ConnectionResetError: #if the server was discinnected 
        print("Game server was closed")

    # Close the client socket
    client_socket.close()
    stop_audio()


# Define a function to handle the Submit button click event
def submit_input():
    input_entry_var.set("submitted")

root = Tk()

myLabel = Label(root, text="Welcome to the game of speed. The aim of this game is to be as fast as possible. Whenever you recieve a number type it down and press enter. GOOD LUCK!")
myLabel.pack() #showing on the screen

server_message_label = Label(root, text="")#create a label for the welcome message 
server_message_label.pack() # show the server message on the label

root.geometry("1000x1000")#specify the size of the window that will appear to the player 
root.title ('Game Time!')

# start() handles connection to the server and communication with it in a background task on a seperate thread
def start():
    t = threading.Thread(target=connect_to_server)
    t.daemon = True
    t.start()
    

# Add a Start button and call start() on click
b = Button(root, text="Start", command=start)
b.pack()

# Create a variable to store the user's input
input_entry_var = StringVar()
#Necessary for creating a functional GUI application that can handle user inputs and events in real-time.
#keep the program running until the user closes the application window or the program is terminated
root.mainloop()