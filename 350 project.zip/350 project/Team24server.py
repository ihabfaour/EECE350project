# -*- coding: utf-8 -*-
"""
Created on Sun Apr 16 15:41:34 2023

@author: User
"""

import socket 
import time 
import random 
import threading
import tkinter as tk

#create a server socket 
server_socket= socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host=socket.gethostname()
host_address= socket.gethostbyname(host)
#bind to the server socket and a specific port 
server_socket.bind((host_address,8080))


# sendInfo is a function that contains all info for each player including: round number,round score, and cumulative score
def sendInfo(player_socket, round_number, round_score, cumulative_score, RTT):
    player_socket.send(f"Your score for round {round_number} is {round_score}\n".encode())
    player_socket.send(f"Your cumulative score {round_number} is {cumulative_score}\n".encode())
    player_socket.send(f"Your Time: {RTT}".encode())

#function to handle the time out of the players 
def ensureThatPlayersAreAwareOfTheTimeout(player1_socket, player2_socket):
    recievedMessage = "" 
    while True:
        data = player1_socket.recv(1024).decode()
        recievedMessage += data
        if "ack::timeout" in data: 
            break

    recievedMessage = "" 
    while True:
        data = player2_socket.recv(1024).decode()
        recievedMessage += data
        if "ack::timeout" in data: 
            break

# game_logic is a funcion that synchronizes between players 1 and 2
def game_logic(player1_socket, player2_socket):

    #to keep tack of player 1 score
    cumulative_score1=[]
    #to keep track of player 2 score
    cumulative_score2=[]

    # initializing cumulative score for players
    player1_cumulative_score = 0
    player2_cumulative_score = 0  

    #set timeout to 30 seconds
    player1_socket.settimeout(30.0)
    player2_socket.settimeout(30.0)

    #play the game for three rounds
    for round in range(1, 4):
        #specify the round number
        print(f"This is round: {round}")
        
        #array to save the sum of player's score after each round
        cumulative_scores=[]
        
        # A function stating the scores
        def player_scores():
            #add player's score to their corresponding list of scores 
            cumulative_score1.append(score1)
            cumulative_score2.append(score2)
            #add the scores of each player together after each round
            SUM1=sum(cumulative_score1)
            SUM2=sum(cumulative_score2)
            #append the sum of scores to the total list and sort them in decreasing order
            cumulative_scores.append(SUM1) 
            cumulative_scores.append(SUM2)
            sorted_list=sorted(cumulative_scores,reverse=True)
            #display the scores in decreading order 
            print("The results in decreasing order are: ",sorted_list)

        randomNumber = random.randint(0,9) # generate a random number to send to the clients 
        print(f'The random number for this round is: {randomNumber}') # printing this random number
        #send the random number to the client 
        player1_socket.send(str(randomNumber).encode()) 
        #start caluculating the RTT of the time needed to send a message to the client and recieve their response back
        start_time = time.time() # start_time used to calculate RTT

        #check if the client is still connected or not
        try:
            player1_input = int(player1_socket.recv(4).decode())
        except ConnectionResetError:
            print("player 1 socket was disconnected") #     Error stating that player1 closed the console
            player2_socket.send("player 1 was disconnected! *".encode()) #send the error to the client 
            return
        #need to check if the client took alot of time to reply then he may be timeout 
        except Exception as e:
            if isinstance(e, socket.timeout): # Timeout is used to specify the acceptable time for the player to reply in.
                print("Player 1:time out")
                #send to the other player that player 2 was disconnected and the game is over 
                player2_socket.send("The other player timedout - GAME OVER :( *".encode())
                player1_socket.send("You timeout - GAME OVER :( *".encode())
                ensureThatPlayersAreAwareOfTheTimeout(player1_socket, player2_socket)
            return 
        RTT1= time.time()-start_time # calculating rtt for player 1

        #start calculating the RTT of player 2 
        start_time2 = time.time() 
        try:
            player2_socket.send(str(randomNumber).encode()) # sending random number to player2
            player2_input = int(player2_socket.recv(4).decode()) # storing player2's input
        except ConnectionResetError:
            print("player 2 socket was disconnected") # error if player2 closed console
            player1_socket.send("player 2 was disconnected! *".encode())
            return
        except Exception as e:
            if isinstance(e, socket.timeout):#error that player 2 timedout 
                print("Player2:time out")
                player2_socket.send("You timeout - GAME OVER*".encode())#send to the other player that player 1 was disconnected and the game is over
                player1_socket.send("Other player:timeout - GAME OVER*".encode())
                ensureThatPlayersAreAwareOfTheTimeout(player1_socket, player2_socket)
            return
        RTT2= time.time() - start_time2#calculating the RTT of player 2
        
        # Set of code used to handle case-by-case scenario printing functions:
            
        # If both players entered a wrong input:
        if player1_input != randomNumber and player2_input != randomNumber:
            score1=0
            print("Both players entered the wrong number\n")
            #send a message to player 1 that he was disqualified from this round 
            player1_socket.send("You entered the wrong number. You were disqualified from this round!\n".encode())
            #send all information mentioned in the sendInfo function to player 1 in each round 
            sendInfo(player1_socket, round, score1, player1_cumulative_score, RTT1)
            player1_socket.send("*".encode())

            #send a message to player 2 that he was disqualified from this round 
            score2=0
            player2_socket.send("You entered the wrong number. You were disqualified from this round !\n".encode())
            #send all information mentioned in the sendInfo function to player 2 in each round
            sendInfo(player2_socket, round, score2, player2_cumulative_score, RTT2)
            player2_socket.send("*".encode())
            player_scores()
            
        # If player1 entered a wrong number and player2 a correct number. send all info needed for each player
        elif player1_input != randomNumber:
            score1=0
            print("Player 1 entered a wrong number and was disqualified from this round")
            player1_socket.send("You entered the wrong number. You were disqualified from this round!\n".encode())
            sendInfo(player1_socket, round, score1, player1_cumulative_score, RTT1)
            player1_socket.send("*".encode())

            #give player 2 one point 
            score2=1
            player2_cumulative_score += 1
            player2_socket.send("You Won this round\n".encode())
            sendInfo(player2_socket, round, score2, player2_cumulative_score, RTT2)
            player2_socket.send("*".encode())
            player_scores()
        # If player2 entered a wrong number and player1 a correct one. send all info need for each player 
        elif player2_input != randomNumber:
            score1=1
            print("player 2 entered a wrong number and he was disqualified from this round")
            #give player 1 one point 
            player1_cumulative_score += 1
            player1_socket.send("You Won this round\n".encode())
            sendInfo(player1_socket, round, score1, player1_cumulative_score, RTT1)
            player1_socket.send("*".encode())

            score2=0
            player2_socket.send("You entered the wrong number. You were disqualified from this round !\n".encode())
            sendInfo(player2_socket, round, score2, player2_cumulative_score, RTT2)
            player2_socket.send("*".encode())
            player_scores()
        
        # If both users replied by correct number, compare their rtt's to identify winner of round, the faster player has the shorter RTT
        else:
            print("Both player entered the correct number")
            # In the upcoming cases, every winner/round would increase his/her round score by 1 and loser would have his/her cumulative score unchanged
            if RTT1 < RTT2: # if player1 was faster => player1 wins and player2 loses the current round
                print("Player 1 was faster and won this round")
                score1=1
                player1_cumulative_score += 1
                player1_socket.send("You Won this round\n".encode())
                sendInfo(player1_socket, round, score1, player1_cumulative_score, RTT1)
                player1_socket.send("*".encode())
                score2=0
                player2_socket.send("You Lost this round\n".encode())
                sendInfo(player2_socket, round, score2, player2_cumulative_score, RTT2)
                player2_socket.send("*".encode())
                player_scores()

            elif RTT2 < RTT1: # if player2 was faster => player2 wins and player1 loses the current round
                print("player 2 was faster and won this round")
                score1=0
                player1_socket.send("You Lost this round\n".encode())
                sendInfo(player1_socket, round, score1, player1_cumulative_score, RTT1)
                player1_socket.send("*".encode())
                score2=1
                player2_cumulative_score += 1
                player2_socket.send("You Won this round\n".encode())
                sendInfo(player2_socket, round, score2, player2_cumulative_score, RTT2)
                player2_socket.send("*".encode())
                player_scores()
            else: # if both replied by a correct number at the same time, both of them would get a point
                #send all info need for each player
                score1=1
                player1_cumulative_score += 1
                player1_socket.send("It is a tie!\n".encode())
                sendInfo(player1_socket, round, score1, player1_cumulative_score, RTT1)
                player1_socket.send("*".encode())
                score2=1
                player2_cumulative_score += 1
                player2_socket.send("It is a tie!\n".encode())
                sendInfo(player2_socket, round, score2, player2_cumulative_score, RTT2)
                player2_socket.send("*".encode())
                player_scores() 
        
        # block until you read the next? from the players
        player1_socket.recv(1024).decode()
        player2_socket.recv(1024).decode()


    print('Game Ended')
    
    # Final Results Time :Winner Announcement !!
    #if player 1 has higher cumulative score then he/she wins 
    if player1_cumulative_score > player2_cumulative_score:
        print(f'Player 1 won the GAME OF SPEED with a score: {player1_cumulative_score}\n')
        player1_socket.send("WINNER WINNER CHICKEN DINNER\n".encode())
        player2_socket.send("You lost the game.Good luck in future ones\n".encode())
    #if player 2 has higher cumulative score then he/she wins 
    elif player2_cumulative_score > player1_cumulative_score:
        print(f'Player 2 won with a score {player2_cumulative_score}\n')
        player1_socket.send("You lost the game .Good luck in future ones\n".encode())
        player2_socket.send("WINNER WINNER CHICKEN DINNER \n".encode())
    else: #if both players got the same score then it is a tie
        print(f'It is a tie! Both player scored {player1_cumulative_score}')
        player1_socket.send("It is a tie. Congratulations Both !".encode())
        player2_socket.send("It is a tie. Congratulations Both !".encode())

    return


# Initial code used to show which player has connected
server_socket.listen()
#greeting = tk.Label(text="Server is waiting for the players to connect")
print("Server is waiting for the players to connect")

while True:
    #accept the connection of player 1
    player1_socket, player_address1 = server_socket.accept()
    player1_socket.settimeout(10)
    #print player's 1 address
    print("Player 1 of address: ", player_address1, "has connected")
    
    #accept the connection of player 2 
    player2_socket, player_address2 = server_socket.accept()
    player2_socket.settimeout(10)
    #print player's 2 address
    print("Player 2 of address: ", player_address2, "has connected")

    #send a welcoming message to each player
    
    message= "Welcome to the game of speed. The aim of this game is to be as fast as possible. Whenever you recieve a number type it down and press enter. GOOD LUCK!"
    player1_socket.sendall(message.encode())
    player2_socket.sendall(message.encode())
    
    game_logic(player1_socket, player2_socket)
    
    break

#References:
#https://www.ssl2buy.com/wiki/port-80-http-vs-port-443-https
#https://reqbin.com/code/python/bnnyomhw/python-requests-proxy-example
#https://www.digitalocean.com/community/tutorials/python-socket-programming-server-client
#https://github.com/topics/client-server
#https://16bpp.net/tutorials/csharp-networking/04d/